const STYLE_ID = "oldlook-2003-theme";
const SHADOW_STYLE_ID = `${STYLE_ID}-shadow`;
const observedShadowRoots = new WeakSet();

const retroStyles = `
  :root {
    color-scheme: light !important;
    font-family: "Times New Roman", Times, serif !important;
  }

  html, body, body * {
    background-image: none !important;
    box-shadow: none !important;
    filter: none !important;
    text-shadow: none !important;
    transition: none !important;
    animation: none !important;
    border-radius: 0 !important;
  }

  html, body {
    background-color: #fff !important;
    color: #000 !important;
  }

  body {
    font-family: "Times New Roman", Times, serif !important;
    font-size: 16px !important;
    line-height: normal !important;
  }

  body, body * {
    font-family: "Times New Roman", Times, serif !important;
    letter-spacing: normal !important;
    background-color: transparent !important;
    color: #000 !important;
  }

  body a:link { color: #0000ee !important; text-decoration: underline !important; }
  body a:visited { color: #551a8b !important; }
  body a:hover { color: #f00 !important; }

  body h1 { font-size: 2em !important; }
  body h2 { font-size: 1.5em !important; }
  body h3 { font-size: 1.17em !important; }
  body h4 { font-size: 1em !important; }
  body h5 { font-size: 0.83em !important; }
  body h6 { font-size: 0.67em !important; }
  body p { margin: 1em 0 !important; }
  body hr { border: 1px inset #808080 !important; }

  body table {
    border-collapse: separate !important;
    border-spacing: 2px !important;
  }

  body th { font-weight: bold !important; text-align: center !important; }
  body pre, body code, body kbd, body samp {
    font-family: "Courier New", Courier, monospace !important;
  }

  body button, body input, body select, body textarea {
    color: #000 !important;
    background: #fff !important;
    border: 2px inset #d4d0c8 !important;
    border-radius: 0 !important;
  }

  body button, body input[type="button"], body input[type="submit"],
  body input[type="reset"] {
    background: #ece9d8 !important;
    border: 2px outset #fff !important;
    cursor: pointer !important;
  }

  body button:active, body input[type="button"]:active,
  body input[type="submit"]:active, body input[type="reset"]:active {
    border-style: inset !important;
  }

  body img, body video, body canvas, body svg {
    border-radius: 0 !important;
  }

`;

const shadowRetroStyles = retroStyles
  .replaceAll(":root", ":host")
  .replaceAll("html, body, body *", ":host, :host *")
  .replaceAll("html, body", ":host")
  .replaceAll("body", ":host");

let themeEnabled = true;

function updateStyle(root, styleId, cssText) {
  const existingStyle = root.querySelector(`#${styleId}`);

  if (!themeEnabled) {
    existingStyle?.remove();
    return;
  }

  if (existingStyle) return;

  const style = document.createElement("style");
  style.id = styleId;
  style.textContent = cssText;
  root.append(style);
}

function scanForShadowRoots(root) {
  if (!root.querySelectorAll) return;

  for (const element of root.querySelectorAll("*")) {
    if (element.shadowRoot) observeShadowRoot(element.shadowRoot);
  }
}

function observeShadowRoot(root) {
  updateStyle(root, SHADOW_STYLE_ID, shadowRetroStyles);

  if (observedShadowRoots.has(root)) return;
  observedShadowRoots.add(root);

  const observer = new MutationObserver((records) => {
    for (const record of records) {
      for (const node of record.addedNodes) scanForShadowRoots(node);
    }
  });
  observer.observe(root, { childList: true, subtree: true });
  scanForShadowRoots(root);
}

function syncDocumentStyle() {
  if (!document.documentElement) return;
  updateStyle(document.documentElement, STYLE_ID, retroStyles);
}

function setTheme(enabled) {
  themeEnabled = enabled;
  syncDocumentStyle();
  scanForShadowRoots(document);
}

const documentObserver = new MutationObserver((records) => {
  syncDocumentStyle();
  for (const record of records) {
    for (const node of record.addedNodes) scanForShadowRoots(node);
  }
});
documentObserver.observe(document, { childList: true, subtree: true });

chrome.storage.sync.get({ enabled: true }, ({ enabled }) => {
  setTheme(enabled);
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "sync" && changes.enabled) {
    setTheme(changes.enabled.newValue);
  }
});