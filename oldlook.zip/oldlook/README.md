# Oldlook 2003

A Manifest V3 extension for Chrome and other Chromium browsers that gives regular websites a classic-web appearance: a plain white document, Times New Roman typography, blue underlined links, browser-default spacing, simple heading sizes, plain tables, square corners, and beveled form controls. It also strips gradients, shadows, filters, and animations from page content.

This changes the appearance, not the website's underlying HTML or JavaScript. Chromium still runs modern websites with its modern browser engine; converting arbitrary sites to HTML 1.0, CSS 1.0, or historical JavaScript would break many of them.

## Install

1. Open `chrome://extensions` in your browser.
2. Turn on **Developer mode**.
3. Select **Load unpacked** and choose this folder.
4. Use the Oldlook 2003 toolbar popup to turn the theme on or off.

The theme is enabled by default and applies to websites in every tab, including eligible embedded frames and open shadow roots. Chromium does not allow extensions to change internal pages such as `chrome://` pages or the Chrome Web Store. Closed shadow roots cannot be reached by this theme.