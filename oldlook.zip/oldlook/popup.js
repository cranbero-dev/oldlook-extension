const enabledToggle = document.getElementById("enabled");
const statusText = document.getElementById("status");

function updateStatus(enabled) {
  statusText.textContent = enabled ? "On for every website" : "Off for every website";
}

chrome.storage.sync.get({ enabled: true }, ({ enabled }) => {
  enabledToggle.checked = enabled;
  updateStatus(enabled);
});

enabledToggle.addEventListener("change", () => {
  const enabled = enabledToggle.checked;
  chrome.storage.sync.set({ enabled });
  updateStatus(enabled);
});